
package Negocio;

import Datos.clientesDAO;
import Entidades.clientes;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class clientesControl {
    private final clientesDAO DATOS;
    private final clientes obj;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;
    
    public clientesControl(){
        this.DATOS=new clientesDAO();
        this.obj=new clientes();
        this.registrosMostrados=0;
    }
    
    public DefaultTableModel listar(String texto){
        List<clientes> lista=new ArrayList();
        lista.addAll(DATOS.listar(texto));
        
        String[] titulos={"Nombre","Email","Telefono","Direccion","Fecha","Activo"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String estado;
        String[] registro = new String[6];
        
        this.registrosMostrados=0;
        for (clientes item:lista){
            if (item.isActivo()){
                estado="Activo";
            } else{
                estado="Inactivo";
            }
            registro[0]=Integer.toString(item.getId());
            registro[1]=item.getNombre();
            registro[2]=item.getEmail();
            registro[2]=item.getTelefono();
            registro[2]=item.getDireccion();
            registro[2]=item.getFecha();
            registro[3]=estado;
            this.modeloTabla.addRow(registro);
            this.registrosMostrados=this.registrosMostrados+1;
        }
        return this.modeloTabla;
    }
    
    public String insertar(String nombre,String descripcion){
        if (DATOS.existe(nombre)){
            return "El registro ya existe.";
        }else{
            obj.setNombre(nombre);
            obj.setEmail(descripcion);
            if (DATOS.insertar(obj)){
                return "OK";
            }else{
                return "Error en el registro.";
            }
        }
    }
    
    public String actualizar( String Nombre,String nombreAnt,String Email, String Telefono, String Direccion, String Fecha){
        if (Nombre.equals(nombreAnt)){

            obj.setNombre(Nombre);
            obj.setEmail(Email);
            obj.setEmail(Telefono);
            obj.setEmail(Direccion);
            obj.setEmail(Fecha);
            if(DATOS.actualizar(obj)){
                return "OK";
            }else{
                return "Error en la actualización.";
            }
        }else{
            if (DATOS.existe(Nombre)){
                return "El registro ya existe.";
            }else{
               
                obj.setNombre(Nombre);
                obj.setEmail(Email);
                obj.setEmail(Telefono);
            obj.setEmail(Direccion);
            obj.setEmail(Fecha);
                if (DATOS.actualizar(obj)){
                    return "OK";
                }else{
                    return "Error en la actualización.";
                }
            }
        }
    }
    
    public String desactivar(int id){
        if (DATOS.desactivar(id)){
            return "OK";
        }else{
            return "No se puede desactivar el registro";
        }
    }
    
    public String activar(int id){
        if (DATOS.activar(id)){
            return "OK";
        }else{
            return "No se puede activar el registro";
        }
    }
    
    public int total(){
        return DATOS.total();
    }
    
    public int totalMostrados(){
        return this.registrosMostrados;
    }
}
