
package Entidades;

public class clientes {
    
    private String nombre;
    private String email;
    private String telefono;
    private String direccion;
    private String fecha;
    private boolean activo;

    //Constructor
    public clientes(String nombre, String email, String telefono, String direccion, String fecha, boolean activo) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
        this.fecha = fecha;
        this.activo = activo;
    }

    public clientes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
//get
    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getFecha() {
        return fecha;
    }

    public boolean isActivo() {
        return activo;
    }
//Set
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    //toString

    @Override
    public String toString() {
        return "clientes{" + "nombre=" + nombre + ", email=" + email + ", telefono=" + telefono + ", direccion=" + direccion + ", fecha=" + fecha + ", activo=" + activo + '}';
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
    
}
